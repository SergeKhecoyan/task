import boto3

s3 = boto3.client('s3')


def lambda_handler(event, context):
    bucket_name_upload = event["Records"][0]["s3"]["bucket"]["name"]
    main_bucket_name = "my-bucket-test-01020304"
    file_name = event["Records"][0]["s3"]["object"]["key"]
    new_file_name = file_name.split(".")[0] + "_test_bucket.jpg"
    copy_source = {'Bucket': bucket_name_upload, 'Key': file_name}
    try:
        s3.copy_object(CopySource=copy_source, Bucket=main_bucket_name, Key=new_file_name)
        s3.delete_object(Bucket=bucket_name_upload, Key=file_name)
    except Exception as e:
        return e
