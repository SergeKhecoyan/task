import base64
import boto3


s3 = boto3.client('s3')

def lambda_handler(event, context):

    base = event["headers"]["base64"]
    if base != "True":
        return "NOT AUTORAZED"

    bucket_name = "my-bucket-test-01020304"
    file_name = event ["queryStringParameters"]["file"]
    fileObj = s3.get_object(Bucket=bucket_name, Key=file_name)
    file_content = fileObj["Body"].read()
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/jpg",
            "Content-Disposition": "attachment; filename={}".format(file_name)
        },
        "body": base64.b64encode(file_content),
        "isBase64Encoded": True
    }
