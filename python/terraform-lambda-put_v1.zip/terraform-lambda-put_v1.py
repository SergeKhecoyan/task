import boto3
import base64
from botocore.exceptions import ClientError

s3 = boto3.client('s3')

response = {
    'statusCode': 200,
    'headers': {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': 'true'
    },
    'body': ''
}


def lambda_handler(event, context):
    base = event["headers"]["base64"]

    if base != "True":
        return base

    bucket_name = "my-bucket-test-for-upload"
    file_name = event["queryStringParameters"]["file"]
    cheack = file_name.split(".")[0] + "_test_bucket.jpg"
    file_content = base64.b64decode(event['body'])

    try:
        my_bucket = s3.head_object(Bucket=bucket_name, Key=file_name)
        response['body'] = 'FILE IS EXIST'
        response['statusCode'] = 500
        return response
    except Exception as e:
        s3.put_object(Bucket=bucket_name, Key=file_name, Body=file_content)
        response['body'] = 'Your file has been uploaded'
        return response
